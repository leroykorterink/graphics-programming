const camera = new THREE.PerspectiveCamera(
  75, // fov — Camera frustum vertical field of view.
  window.innerWidth / window.innerHeight, // aspect — Camera frustum aspect ratio.
  0.1, // near — Camera frustum near plane.
  1000
); // far — Camera frustum far plane.

camera.position.set(-0.5, 1, 5);

export default camera;
