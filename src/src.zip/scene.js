export default new THREE.Scene();
