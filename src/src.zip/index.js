const importModule = async path => {
  const module = await import(path);
  return module.default;
};

const createLoadComponent = scene => async path => {
  const component = await importModule(`./components/${path}`);

  if (typeof component === "function") {
    return component(scene);
  } else if (component && component.isObject3D) {
    return scene.add(component);
  }

  throw new Error(`Cannot load component ${path}`);
};

const initialize = async () => {
  // Create scene
  const renderer = await importModule("./renderer.js");
  const scene = await importModule("./scene.js");
  const camera = await importModule("./camera.js");

  const components = ["box.js"];

  const loadComponent = createLoadComponent(scene);
  await Promise.all(components.map(loadComponent)).catch(console.error);

  const render = () => {
    requestAnimationFrame(render);
    renderer.render(scene, camera);
  };

  // Start first render
  render();
};

initialize();
